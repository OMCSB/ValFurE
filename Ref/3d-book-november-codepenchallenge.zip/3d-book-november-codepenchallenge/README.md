# 3d book (November #CodePenChallenge)

A Pen created on CodePen.io. Original URL: [https://codepen.io/lina994/pen/qBXGvby](https://codepen.io/lina994/pen/qBXGvby).

