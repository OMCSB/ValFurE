# Books Hover Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/yancy/pen/jpWPGx](https://codepen.io/yancy/pen/jpWPGx).

