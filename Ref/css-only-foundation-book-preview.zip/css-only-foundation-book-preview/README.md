# CSS-only  Foundation book preview

A Pen created on CodePen.io. Original URL: [https://codepen.io/diemoritat/pen/LKROYZ](https://codepen.io/diemoritat/pen/LKROYZ).

Inspired by The Folio Society edition of the Foundation Trilogy (https://www.foliosociety.com/uk/the-foundation-trilogy.html). The amazing illustration was made by Alex Wells (https://www.wellsillustration.com/).

This is quite simple for now, but I'm thinking about adding one or two more pages. Any ideas?